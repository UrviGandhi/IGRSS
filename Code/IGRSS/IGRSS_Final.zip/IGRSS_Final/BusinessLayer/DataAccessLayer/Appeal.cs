﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class Appeal {
        partial class AppealActsApplicableDataTable
        {
        }
    
		partial class AppealHearingDataTable
		{
		}
	
		partial class AppealApplicationDataTable
		{
		}
	}
}
