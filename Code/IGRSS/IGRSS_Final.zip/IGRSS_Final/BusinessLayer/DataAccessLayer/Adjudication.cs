﻿namespace IGRSS.DataAccessLayer {


	partial class Adjudication
	{
		partial class AdjudicationRequestDataTable
		{
		}
	
		partial class ValuationFormDataTable
		{
		}
	
		partial class AdjudicationFeeDetailsDataTable
		{
		}
	}
}
