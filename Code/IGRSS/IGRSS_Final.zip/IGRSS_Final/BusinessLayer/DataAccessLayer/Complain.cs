﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class Complain {
		partial class ComplainDetailsDataTable
		{
		}
	
		partial class ComplainDatatableDataTable
		{
		}
	}
}
