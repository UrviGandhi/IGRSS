﻿namespace IGRSS.DataAccessLayer {


	partial class InwardOutward
	{
        partial class Inward_OutwardRegisterDataTable
        {
        }
    
		partial class PostalStampPurchaseReqDataTable
		{
		}
	
		partial class PostalDeliveryType_LKPDataTable
		{
		}
	}
}


namespace IGRSS.DataAccessLayer.InwardOutwardTableAdapters {
    
    
    public partial class Inward_OutwardRegisterTableAdapter {
    }
}
