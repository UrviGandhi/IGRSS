﻿namespace IGRSS.DataAccessLayer {


    partial class FileManagement
    {
    }
}
