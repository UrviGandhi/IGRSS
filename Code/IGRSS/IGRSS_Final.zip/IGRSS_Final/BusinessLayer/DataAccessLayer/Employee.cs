﻿namespace IGRSS.DataAccessLayer {


	partial class Employee
	{
		partial class EmployeeMasterDataTable
		{
		}
	
		partial class EmployeeQualificationsDataTable
		{
		}
	
		partial class QualificationMasterDataTable
		{
		}
	
		partial class DesignationMasterDataTable
		{
		}
	}
}
