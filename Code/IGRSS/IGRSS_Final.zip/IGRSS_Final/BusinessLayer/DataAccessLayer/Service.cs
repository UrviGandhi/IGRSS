﻿namespace IGRSS.DataAccessLayer {


	partial class Service
	{
    }
}
