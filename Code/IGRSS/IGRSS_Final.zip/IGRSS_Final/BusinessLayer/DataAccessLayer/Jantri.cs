﻿namespace IGRSS.DataAccessLayer {


    partial class Jantri
    {
    }
}
