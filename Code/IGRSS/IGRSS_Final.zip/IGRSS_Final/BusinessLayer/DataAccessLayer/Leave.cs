﻿namespace IGRSS.DataAccessLayer {


	partial class Leave
	{
		partial class LeaveRegisterDataTable
		{
		}
	}
}
