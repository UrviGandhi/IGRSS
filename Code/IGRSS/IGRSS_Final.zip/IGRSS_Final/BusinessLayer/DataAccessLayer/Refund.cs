﻿namespace IGRSS.DataAccessLayer {


	partial class Refund
	{
		partial class RefundActsApplicableDataTable
		{
		}
	}
}
