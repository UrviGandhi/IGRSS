﻿namespace IGRSS.DataAccessLayer {


	partial class LicenseReNewal
	{
		partial class RenewLicenseDataTable
		{
		}
	}
}
