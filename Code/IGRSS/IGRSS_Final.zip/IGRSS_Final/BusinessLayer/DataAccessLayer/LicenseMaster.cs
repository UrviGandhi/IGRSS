﻿namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.DataAccessLayer
{
}
namespace IGRSS.BusinessLayer.DataAccessLayer
{
}
namespace IGRSS.BusinessLayer.DataAccessLayer
{
}
namespace IGRSS.BusinessLayer.DataAccessLayer
{
}
namespace IGRSS.BusinessLayer.DataAccessLayer
{
}
namespace IGRSS.BusinessLayer.DataAccessLayer
{
}
partial class LicenseMaster
{
	partial class LicenseMasterDataTable
	{
	}
}
