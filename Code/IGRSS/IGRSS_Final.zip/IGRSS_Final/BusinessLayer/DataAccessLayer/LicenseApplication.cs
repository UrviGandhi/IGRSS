﻿using System;
namespace IGRSS.DataAccessLayer
{


	partial class LicenseApplication
	{
		[Serializable]
		public partial class LicenseApplicationRow
		{
		}
	}
}
