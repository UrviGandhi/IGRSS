﻿namespace IGRSS.DataAccessLayer {


	partial class Test
	{
		
    }
}
