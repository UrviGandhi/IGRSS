﻿namespace IGRSS.DataAccessLayer {


    partial class VendorOffence
    {
        partial class VendorInvestigationDataTable
        {
        }
    
        partial class HighCourtAppealDataTable
        {
        }
    
        partial class VendorOffenceDataTable
        {
        }
    }
}
