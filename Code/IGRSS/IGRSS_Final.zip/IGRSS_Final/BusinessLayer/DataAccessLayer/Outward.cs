﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class Outward {
    }
}

namespace IGRSS.DataAccessLayer.OutwardTableAdapters{
    
    
    public partial class OutwardRegisterTableAdapter {
    }
}
