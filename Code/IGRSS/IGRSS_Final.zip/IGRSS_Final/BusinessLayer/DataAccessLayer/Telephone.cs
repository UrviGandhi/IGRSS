﻿namespace IGRSS.DataAccessLayer {


	partial class Telephone
	{
		partial class TelephoneRegisterDataTable
		{
		}
	}
}
