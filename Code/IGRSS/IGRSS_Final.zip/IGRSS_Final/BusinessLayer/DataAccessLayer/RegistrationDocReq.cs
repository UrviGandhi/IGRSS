﻿namespace IGRSS.DataAccessLayer {


    partial class RegistrationDocReq
    {
        partial class RegistrationTypeDoc_MapMasterDataTable
        {
        }
    }
}
