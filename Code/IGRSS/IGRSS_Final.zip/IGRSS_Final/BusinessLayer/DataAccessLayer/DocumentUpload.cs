﻿namespace IGRSS.DataAccessLayer {


    partial class DocumentUpload
    {
    }
}
