﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class TestTable {
    }
}

namespace IGRSS.TestTableTableAdapters {
    
    
    public partial class TestTableAdapter {
    }
}
