﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class InspectionDetails {
    }
}
