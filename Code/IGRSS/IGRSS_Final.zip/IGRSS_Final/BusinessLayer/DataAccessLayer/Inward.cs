﻿namespace IGRSS.DataAccessLayer {
    
    
    public partial class Inward {
    }
}

namespace IGRSS.DataAccessLayer.InwardTableAdapters {
    
    
    public partial class InwardRegisterTableAdapter {
    }
}
