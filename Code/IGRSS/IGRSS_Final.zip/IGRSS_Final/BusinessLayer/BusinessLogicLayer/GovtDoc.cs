﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.ComponentModel;
using IGRSS.BusinessObjects;
using System.Threading;
using Microsoft.Practices.EnterpriseLibrary.ExceptionHandling;


namespace IGRSS.BusinessLogicLayer
{
    class GovtDoc
    {
        //[DataObjectMethodAttribute(DataObjectMethodType.Insert, true)]
        //public bool AddDoc(FormViewParameter Parameter)
        //{
        //    try
        //    {
        //        IGRSS.DataAccessLayer.GovtDoc.GovtDocsRow Row = (IGRSS.DataAccessLayer.GovtDoc.GovtDocsRow)Parameter.Values;
        //        int i = IgrssAdapters.GovtTableAdapter.Insert(1, 2, "Details", 23, DateTime.Now, "Department1", 123, "Output Details", "Details Of Preserving Files", "Types Of Record", "Remarks");
        //          if (i == 1)
        //            return true;
        //        else
        //            return false;
        //    }

        //    catch(Exception ex)
        //    {

        //        if (ExceptionPolicy.HandleException(ex, "DAL"))
        //            throw;
        //        return false;
            
            }
        
        
        }
    

