using System;
using System.Collections.Generic;
using System.Text;

namespace IGRSS.BusinessLogicLayer
{
	public class Test
	{
         public int add(int a,int b)
         {

             return a + b;
        }
        
	}
   

    
}
