using System;
using System.Collections.Generic;
using System.Text;

namespace IGRSS.Workflows.License.Events
{
	class LicenseApplicationEventArgs
	{
	}
}
