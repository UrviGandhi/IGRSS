public enum MessageType
{
    Error,
    Success,
    Information
}